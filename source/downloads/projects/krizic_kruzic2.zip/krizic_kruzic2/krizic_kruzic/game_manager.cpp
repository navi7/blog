#include "game_manager.h"
#include <iostream>
#include <string>

using std::cout; using std::endl;
using std::cin; using std::string;

void game_manager::play() {
	while (true) {
		show_menu();
		option_type option = get_option();
		if (option == option_type::exit) {
			return;
		}

		do_option(option);
	}
}

void game_manager::show_menu() {
	cout << "krizic-kruzic v0.0.1. alpha" << endl;
	cout << "===========================" << endl;
	cout << "1. Top 10" << endl;
	cout << "2. Nova igra" << endl;
	cout << "3. Kraj" << endl;
}

game_manager::option_type game_manager::get_option() {
	while (true) {
		cout << "> ";
		string input;
		cin >> input;

		if (input.length() == 1) {
			switch (input[0]) {
			case '1':
				return option_type::top_ten;
			case '2':
				return option_type::play_game;
			case '3':
				return option_type::exit;
			default:
				cout << "Ne razumijem!" << endl;
				break;
			}
		}
		else {
			cout << "Hmmm.. ne razumijem sto zelis??" << endl;
		}
	}
}

void game_manager::do_option(option_type option) {
	switch (option) {
	case option_type::play_game:
		play_new_game();
	case option_type::top_ten:
		show_top_ten();
	}
}


void game_manager::play_new_game() {
}

void game_manager::show_top_ten() {
	cout << "Top 10 lista" << endl;
	cout << "------------" << endl;
	cout << "Nick      Played Won Lost Draw" << endl;
	//       123456789012345678901234567890
	//                1         2         3

	//TODO: dovr�iti 

	// u�itaj popis korisnika iz datoteke
	// izvuci 10 s najbi�e pobjeda
	// ispi�i tu listu
}


