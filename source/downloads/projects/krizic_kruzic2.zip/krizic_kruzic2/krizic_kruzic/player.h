#include <string>

class player {
	std::string nick();
	void nick(const std::string& nick);

private:
	std::string m_nick;

public:
	int played;
	int won;
	int draw;
};
