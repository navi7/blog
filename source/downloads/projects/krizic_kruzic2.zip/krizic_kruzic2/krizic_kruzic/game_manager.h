// klasa game_manager
// pokre�e glavnu petlju igre

class game_manager {

public:
	void play();

private:
	enum option_type { top_ten, play_game, exit };

	void show_menu();
	option_type get_option();
	void do_option(option_type option);

	void play_new_game();
	void show_top_ten();
};
