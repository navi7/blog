#include <iostream>

#include "game_manager.h"

int main() {

	game_manager gm;
	gm.play();

	return 0;
}
