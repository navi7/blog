#include "player.h"

std::string player::nick() {
	return m_nick;
}

void player::nick(const std::string& nick) {
	this->m_nick = nick;
}