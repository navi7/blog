// datoteka zaglavlja
// sadr�i najave funkcija
namespace racunarstvo {

double zbroji(double, double);


} // end namespace