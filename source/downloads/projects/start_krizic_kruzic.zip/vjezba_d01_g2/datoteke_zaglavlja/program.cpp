#include <iostream>
#include "funkcije.h"

int main() { 

	double rez = racunarstvo::zbroji(16.42, 42.16);
	std::cout << "Ako zbrojim 16.42 i 42.16 "
		<< "dobijem " << rez << std::endl;

	return 0;
}