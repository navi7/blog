// implementacije raznih funkcija
#include "funkcije.h"

namespace racunarstvo {

double zbroji(double x, double y) {
	return x + y;
}


} // end namespace
