#include "game_manager.h"


void game_manager::play() {
	while (true) {
		show_menu();
		option_type option = get_option();

		do_option(option);
	}
}

void game_manager::show_menu() {
}

game_manager::option_type game_manager::get_option() {

	return option_type::exit;
}

void game_manager::do_option(option_type option) {
}


